package iade.Projeto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GreenFitApplication {

	public static void main(String[] args) {
		SpringApplication.run(GreenFitApplication.class, args);
	}

}
